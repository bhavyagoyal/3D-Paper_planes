#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>
#include <stdlib.h>
#include <utility>
#include <unistd.h>
#include <climits>
#include <random>
#include <vector>
#include <string>

#include "terrain.h"
extern terrain a,b,c;
extern int front;
extern double planex,planez,planey;
extern GLfloat aspect;
extern double SCALE,HEIGHTSCALE;
